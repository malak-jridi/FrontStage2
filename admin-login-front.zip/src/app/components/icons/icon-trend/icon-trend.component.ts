import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-trend',
  templateUrl: './icon-trend.component.html',
  styleUrls: ['./icon-trend.component.css']
})
export class IconTrendComponent {

}
