import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-check-mark',
  templateUrl: './icon-check-mark.component.html',
  styleUrls: ['./icon-check-mark.component.css']
})
export class IconCheckMarkComponent {

}
