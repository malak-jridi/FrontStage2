import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-star-badge',
  templateUrl: './icon-star-badge.component.html',
  styleUrls: ['./icon-star-badge.component.css']
})
export class IconStarBadgeComponent {

}
