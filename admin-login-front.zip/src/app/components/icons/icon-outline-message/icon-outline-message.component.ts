import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-outline-message',
  templateUrl: './icon-outline-message.component.html',
  styleUrls: ['./icon-outline-message.component.css']
})
export class IconOutlineMessageComponent {

}
