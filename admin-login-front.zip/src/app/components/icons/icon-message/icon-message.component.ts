import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-message',
  templateUrl: './icon-message.component.html',
  styleUrls: ['./icon-message.component.css']
})
export class IconMessageComponent {

}
