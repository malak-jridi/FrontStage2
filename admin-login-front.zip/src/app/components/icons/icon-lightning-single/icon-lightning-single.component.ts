import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-lightning-single',
  templateUrl: './icon-lightning-single.component.html',
  styleUrls: ['./icon-lightning-single.component.css']
})
export class IconLightningSingleComponent {

}
