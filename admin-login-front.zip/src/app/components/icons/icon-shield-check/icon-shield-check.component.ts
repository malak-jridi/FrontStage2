import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-shield-check',
  templateUrl: './icon-shield-check.component.html',
  styleUrls: ['./icon-shield-check.component.css']
})
export class IconShieldCheckComponent {

}
