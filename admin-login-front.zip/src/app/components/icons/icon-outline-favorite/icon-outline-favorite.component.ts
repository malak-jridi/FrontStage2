import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-outline-favorite',
  templateUrl: './icon-outline-favorite.component.html',
  styleUrls: ['./icon-outline-favorite.component.css']
})
export class IconOutlineFavoriteComponent {

}
