import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-comment',
  templateUrl: './icon-comment.component.html',
  styleUrls: ['./icon-comment.component.css']
})
export class IconCommentComponent {

}
