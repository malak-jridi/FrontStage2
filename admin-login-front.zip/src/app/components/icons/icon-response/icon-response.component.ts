import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-response',
  templateUrl: './icon-response.component.html',
  styleUrls: ['./icon-response.component.css']
})
export class IconResponseComponent {

}
