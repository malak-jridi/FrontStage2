import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-aim',
  templateUrl: './icon-aim.component.html',
  styleUrls: ['./icon-aim.component.css']
})
export class IconAimComponent {

}
