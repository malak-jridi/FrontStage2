import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-rating-star',
  templateUrl: './icon-rating-star.component.html',
  styleUrls: ['./icon-rating-star.component.css']
})
export class IconRatingStarComponent {

}
