import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-lightning',
  templateUrl: './icon-lightning.component.html',
  styleUrls: ['./icon-lightning.component.css']
})
export class IconLightningComponent {

}
