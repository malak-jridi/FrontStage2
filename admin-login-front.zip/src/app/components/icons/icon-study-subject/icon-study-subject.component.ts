import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-study-subject',
  templateUrl: './icon-study-subject.component.html',
  styleUrls: ['./icon-study-subject.component.css']
})
export class IconStudySubjectComponent {

}
