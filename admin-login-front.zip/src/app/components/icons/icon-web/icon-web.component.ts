import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-web',
  templateUrl: './icon-web.component.html',
  styleUrls: ['./icon-web.component.css']
})
export class IconWebComponent {
}
