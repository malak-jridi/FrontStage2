import { Component } from '@angular/core';

@Component({
  selector: 'app-icon-outline-question',
  templateUrl: './icon-outline-question.component.html',
  styleUrls: ['./icon-outline-question.component.css']
})
export class IconOutlineQuestionComponent {

}
